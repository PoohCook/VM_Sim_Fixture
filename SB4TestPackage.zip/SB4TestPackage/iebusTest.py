from argparse import ArgumentParser
import time
from analog import *
from framework import *


class IebusTest():
    def __init__(self, framework: TestFramework) -> None:
        self.__framework = framework

    def scanAtVoltage(self, bias):
        self.__framework.fixtureSetDacValue(DacChannel.DacChannel1, int(bias / 2))
        time.sleep(0.2)
        sAddr = f"08{(bias & 0xff):02x}"
        print(f"sAddr = ")
        ie_out = f'broad:no mAddr:0800 sAddr:{sAddr} com:0e data:[30,31,32,33,34]'
        self.__framework.consoleSendNoWait(command=f"test_ie send {ie_out}")

        adcData = self.__framework.fixtureAdcReadData(channel=SenseChannel.SenseIeDiff, size=120, scale=2,
                                                        trigger=TriggerSource.TriggerIeDetect)

        class_profiles = [
            [400, [-0.4, -0.1]],
            [4600, [-0.6, -0.1]],
            [6000, [-0.4, -0.1]]
        ]

        profile = class_profiles[-1]
        for pr in class_profiles:
            if bias < pr[0]:
                profile = pr[1]
                break

        volt_classes = AnalogData.clasifyAnalogData(adcData, profile)
        passed_voltage = volt_classes[0] > 10 and volt_classes[2] > 10
        self.__framework.addStepNote(f"Voltage Classification: {volt_classes}")

        self.__framework.consoleGetResult()

        self.__framework.pause()
        lines = self.__framework.consoleSend(command=f"test_ie read")
        readbacks = lines[:-1]
        self.__framework.consoleSend(command="test_ie reset")
        expect = [
            f'IebusV2Frame(status:2 broad:False maddr:0800 saddr:{sAddr} con:e data:[30,31,32,33,34])',
            f'IebusV2Frame(status:2 broad:False maddr:0800 saddr:{sAddr} con:e data:[30,31,32,33,34])',
            f'IebusV2Frame(status:2 broad:False maddr:0800 saddr:{sAddr} con:e data:[30,31,32,33,34])',
        ]
        passed_readback = (readbacks == expect)
        self.__framework.addResult(name=f"IE readback and differential range: {bias} mV",
                                   result=(passed_voltage and passed_readback))

    def run(self, min=0, max=5000, step=500):
        self.__framework.start("IEBus loopback test")

        self.__framework.fixtureSetMux(InputMux.NoConnect, OutputMux.NoConnect)
        self.__framework.consoleSend(command="test_ie reset")
        self.__framework.fixtureSetDacValue(DacChannel.DacChannel1, 0)
        time.sleep(1.0)

        for bias in range(min, max + 1, step):
            self.scanAtVoltage(bias)


if __name__ == "__main__":

    local = ArgumentParser(add_help=False)
    local.add_argument('-m', '--max_bias', type=int, default=5000, help="Max bias to run in mV")
    local.add_argument('-n', '--min_bias', type=int, default=0, help="Min bias to run in mV")
    local.add_argument('-b', '--bias_step', type=int, default=500, help="Bias step by x mv")

    parser = TestArguments("IebusTest", [local])
    args = parser.parse_args()
    framework = TestFramework(args=args)

    for i in range(args.run_cycles):
        test = IebusTest(framework)
        test.run(min=args.min_bias, max=args.max_bias, step=args.bias_step)

    framework.report()
    framework.shutdown()
